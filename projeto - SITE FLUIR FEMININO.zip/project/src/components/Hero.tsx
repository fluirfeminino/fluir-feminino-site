import { Check, Sparkles } from 'lucide-react';

interface HeroProps {
  onCTAClick: () => void;
}

function Hero({ onCTAClick }: HeroProps) {
  return (
    <section className="relative bg-gradient-to-br from-rose-50 via-pink-50 to-amber-50 overflow-hidden">
      <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHZpZXdCb3g9IjAgMCA2MCA2MCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyBmaWxsPSJub25lIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiPjxnIGZpbGw9IiNmZmZmZmYiIGZpbGwtb3BhY2l0eT0iMC40Ij48cGF0aCBkPSJNMzYgMzBoLTJ2LTJoMnYyem0wIDRoLTJ2LTJoMnYyem00LTRoLTJ2LTJoMnYyem00IDRoLTJ2LTJoMnYyeiIvPjwvZz48L2c+PC9zdmc+')] opacity-40"></div>

      <div className="container mx-auto px-4 py-16 md:py-24 relative z-10">
        <div className="grid md:grid-cols-2 gap-12 items-center">
          <div className="order-2 md:order-1">
            <div className="inline-flex items-center gap-2 bg-white/80 backdrop-blur-sm px-4 py-2 rounded-full mb-6 shadow-sm">
              <Sparkles className="w-4 h-4 text-rose-500" />
              <span className="text-sm font-medium text-gray-700">Método Natural e Comprovado</span>
            </div>

            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-gray-900 leading-tight mb-6">
              Controle a fome, reduza o inchaço e conquiste uma{' '}
              <span className="text-rose-500">barriga mais leve</span> naturalmente
            </h1>

            <p className="text-lg md:text-xl text-gray-700 mb-8 leading-relaxed">
              Um plano simples com receitas práticas e estratégias naturais para você começar hoje.
            </p>

            <div className="space-y-4 mb-10">
              {[
                'Como diminuir a compulsão alimentar',
                'Receitas para desinchar rápido',
                'Estratégias naturais para secar a barriga'
              ].map((item, index) => (
                <div key={index} className="flex items-start gap-3">
                  <div className="bg-green-500 rounded-full p-1 mt-1 flex-shrink-0">
                    <Check className="w-4 h-4 text-white" />
                  </div>
                  <span className="text-gray-800 text-lg">{item}</span>
                </div>
              ))}
            </div>

            <button
              onClick={onCTAClick}
              className="w-full md:w-auto bg-gradient-to-r from-green-500 to-green-600 hover:from-green-600 hover:to-green-700 text-white font-bold text-lg px-12 py-5 rounded-full shadow-xl hover:shadow-2xl transform hover:scale-105 transition-all duration-200"
            >
              COMEÇAR AGORA
            </button>

            <p className="text-sm text-gray-600 mt-4">
              Acesso imediato após a compra
            </p>
          </div>

          <div className="order-1 md:order-2 flex justify-center">
            <div className="relative">
              <div className="absolute inset-0 bg-gradient-to-br from-rose-400 to-amber-400 blur-3xl opacity-30 animate-pulse"></div>
              <img
                src="https://i.ibb.co/PvFTV6tS/123.png"
                alt="Ebook Barriga Leve Feminina"
                className="relative rounded-2xl shadow-2xl w-full max-w-md transform hover:scale-105 transition-transform duration-300"
              />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

export default Hero;
