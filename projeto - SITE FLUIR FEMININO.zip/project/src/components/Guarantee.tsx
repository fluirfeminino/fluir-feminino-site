import { Shield, RefreshCw } from 'lucide-react';

function Guarantee() {
  return (
    <section className="py-16 md:py-24 bg-gradient-to-br from-green-50 to-emerald-50">
      <div className="container mx-auto px-4">
        <div className="max-w-3xl mx-auto">
          <div className="bg-white rounded-3xl shadow-xl p-8 md:p-12 text-center">
            <div className="bg-green-500 w-24 h-24 rounded-full flex items-center justify-center mx-auto mb-6">
              <Shield className="w-12 h-12 text-white" />
            </div>

            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-6">
              Garantia Incondicional de 7 Dias
            </h2>

            <p className="text-lg md:text-xl text-gray-700 mb-8 leading-relaxed">
              Estamos tão confiantes nos resultados do método{' '}
              <strong>Barriga Leve Feminina</strong> que oferecemos uma garantia total.
            </p>

            <div className="bg-green-50 rounded-2xl p-8 mb-8">
              <div className="flex items-center justify-center gap-3 mb-4">
                <RefreshCw className="w-6 h-6 text-green-600" />
                <h3 className="text-2xl font-bold text-gray-900">
                  100% Sem Risco
                </h3>
              </div>
              <p className="text-gray-700 text-lg leading-relaxed">
                Se em 7 dias você não estiver satisfeita com o conteúdo,
                basta enviar um e-mail e devolvemos 100% do seu investimento.
                Sem perguntas, sem burocracia.
              </p>
            </div>

            <p className="text-gray-600 italic">
              Você não tem nada a perder e uma barriga mais leve a ganhar!
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}

export default Guarantee;
